﻿using DataTier;

namespace LogicTier
{
    public class ТоварнаяПозиция
    {
        private Товар _товар;

        public ТоварнаяПозиция(Товар p)
        {
            _товар = p;
        }

        public string товар
        {
            get => _товар.товар;
            set => _товар.товар = value;
        }

        public string ТоварнаяГруппа
        {
            get => _товар.ТоварнаяГруппа;
            set => _товар.ТоварнаяГруппа = value;
        }

        public float Цена
        {
            get => _товар.Цена;
            set => _товар.Цена = value;
        }

        public string Склад
        {
            get => _товар.Склад;
            set => _товар.Склад = value;
        }

        public string ПредставлениеТовара => $"{товар} ({ТоварнаяГруппа}) - Цена: {Цена} $, Склад: {Склад}";
    }
}