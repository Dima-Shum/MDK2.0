﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using DataTier;

namespace LogicTier
{
    public class Магазин
    {
        private List<ТоварнаяПозиция> _товарыПозиции;

        public Магазин(List<ТоварнаяПозиция> позиции)
        {
            _товарыПозиции = позиции;
            СредниеЦеныПоГруппам = ВычислитьСредниеЦены();
            СкладМаксПродукции = НайтиСкладМаксимальнойПродукции();
        }

        public List<ТоварнаяПозиция> СписокТоваров => _товарыПозиции;
        public ObservableCollection<СредняяЦенаГруппы> СредниеЦеныПоГруппам { get; }
        public string СкладМаксПродукции { get; }

        public string НаименованиеМагазина => "Наш магазин";

        private ObservableCollection<СредняяЦенаГруппы> ВычислитьСредниеЦены()
        {
            return new ObservableCollection<СредняяЦенаГруппы>(
                _товарыПозиции
                    .GroupBy(p => p.ТоварнаяГруппа)
                    .Select(group => new СредняяЦенаГруппы
                    {
                        ТоварнаяГруппа = group.Key,
                        СредняяЦена = group.Average(p => p.Цена)
                    })
                    .OrderBy(g => g.ТоварнаяГруппа)
            );
        }

        private string НайтиСкладМаксимальнойПродукции()
        {
            return _товарыПозиции
                .GroupBy(p => p.Склад)
                .OrderByDescending(group => group.Count())
                .FirstOrDefault()?
                .Key ?? "Нет данных";
        }
    }

    public class СредняяЦенаГруппы
    {
        public string ТоварнаяГруппа { get; set; }
        public float СредняяЦена { get; set; }

        public string ПредставлениеГруппы =>
            $"{ТоварнаяГруппа} — Средняя цена: {СредняяЦена:F2} $";
    }
}