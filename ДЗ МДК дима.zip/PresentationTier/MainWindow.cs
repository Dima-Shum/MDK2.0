﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier
{
    public partial class MainWindow : Window
    {
        private Магазин магазин;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void Button_Click(object sender, RoutedEventArgs e)
        {
            List<Товар> товары = ВсеТовары.ПолучитьВсеТоварыИзФайла();
            if (товары.Count == 0)
            {
                MessageBox.Show("Нет товаров в файле");
                return;
            }

            List<ТоварнаяПозиция> позиции = new List<ТоварнаяПозиция>();
            foreach (var p in товары)
            {
                позиции.Add(new ТоварнаяПозиция(p));
            }

            магазин = new Магазин(позиции);
            this.DataContext = магазин;
        }

        public void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog.Title = "Сохранить товар";

            if (saveFileDialog.ShowDialog() != true)
            {
                return;
            }

            string filePath = saveFileDialog.FileName;

            string товар = tovar.Text;
            string товарнаяГруппа = group_tovar.Text;
            string цена = price.Text;
            string склад = warehouse.Text;

            if (string.IsNullOrWhiteSpace(товар) ||
                string.IsNullOrWhiteSpace(товарнаяГруппа) ||
                string.IsNullOrWhiteSpace(цена) ||
                string.IsNullOrWhiteSpace(склад))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            if (!float.TryParse(цена, out float ценаЧисло))
            {
                MessageBox.Show("Цена должна быть числом!");
                return;
            }

            string строкаДляЗаписи = $"{товар}%{товарнаяГруппа}%{ценаЧисло}%{склад}";

            try
            {
                File.AppendAllText(filePath, строкаДляЗаписи + Environment.NewLine, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }
    }
}